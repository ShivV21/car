import {COUNTER_DECREASE, COUNTER_INCREASE} from "../actionTypes";

export const increase = value => value ({
  type: COUNTER_INCREASE,
  payload: {
    increament: value
  }
})

export const decrease = value => value ({
  type: COUNTER_DECREASE,
  payload: {
    decrement: value
  }
});
export const increaseby2 = {
 type: "COUNTER_INCREASE",
 payload: {
   increament : 2
 }
}
