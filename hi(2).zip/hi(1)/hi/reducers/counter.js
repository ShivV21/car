import {COUNTER_INCREASE, COUNTER_DECREASE } from "../actionTypes";

const intialState = {
  value: 0
};

export default function(state = intialState, action) {
  switch (action.type) {
    case COUNTER_INCREASE:{
      const {increament } = action.payload;
      return {
        ...state,
        value: state.value + increament
     };
}
case COUNTER_DECREASE:{
      const {decreament } = action.payload;
      return {
        ...state,
        value: state.value + decreament
     };
}
default: 
return state;
}
}