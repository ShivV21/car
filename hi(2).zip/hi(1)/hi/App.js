import * as React from 'react';
import CounterApp from '/components/counterApp';
import store from 'react-redux';

const App = () => {
  return (
    <Provider store={store}>
      <CounterApp/>
    </Provider>
   );
}

export default App;