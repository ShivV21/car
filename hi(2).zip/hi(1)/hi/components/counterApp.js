import * as React from `react`;
import {Text, View, Stylesheet,TouchableOpacity, FlatList, TextInput, Button} from 'react-native';
import { connect } from 'react-redux';



const counterApp = ({ counter, increase, decrease}) => {
  const handleIncrease = () => {increase(5);};
 const handleDecrease = () => {increase(5);};
  return (
     <view style ={style.container}>
     <Text style={styles.text}> Counter Value is "{counter}</Text>
    <Button title="Increase" onPress={handleIncrease} />
    <View style={styles.seperator}></View>
    <Button tittle="Decrease" onPress={handleDecrease} />
    </view>
    );
};

const styles = stylesheet.create(
   {container: {flex: 1, paddingTop: 20, backgroundColor: '#ecf0f1', padding: 10},
seperator: {height: 10,},
text: {textAlign: 'center', height: 30, lineHeight: 30}});

const mapStateToProps = (state) => ({counter: state.counter.value});
const mapDpispatchToProps = {increase, decrease};

export default connect(mapstateToProps, mapDispactToProps)(counterApp);